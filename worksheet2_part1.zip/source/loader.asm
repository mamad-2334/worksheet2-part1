; Minimal Multiboot loader

[bits 32]

global loader
extern kernel_main

section .multiboot
align 4

MULTIBOOT_MAGIC     equ 0x1BADB002
MULTIBOOT_FLAGS     equ 0x00000003
MULTIBOOT_CHECKSUM  equ -(MULTIBOOT_MAGIC + MULTIBOOT_FLAGS)

dd MULTIBOOT_MAGIC
dd MULTIBOOT_FLAGS
dd MULTIBOOT_CHECKSUM

section .text
align 4

loader:
    ; simple stack
    mov esp, stack_top

    ; small debug: write 'X' at top-left
    mov dword [0xB8000], 0x0F58   ; 'X' white on black

    call kernel_main

.hang:
    cli
    hlt
    jmp .hang

section .bss
align 16
stack_bottom:
    resb 16384
stack_top:
